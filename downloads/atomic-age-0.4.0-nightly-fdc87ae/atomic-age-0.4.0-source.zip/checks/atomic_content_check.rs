//! Development check: parse every generated command with the pinned game's dispatcher.
use horizon_command::{Registries,vanilla};
use std::{env,fs,path::Path};
fn visit(root:&Path,out:&mut Vec<std::path::PathBuf>) {
    for file in fs::read_dir(root).unwrap() {
        let path=file.unwrap().path();
        if path.is_dir() { visit(&path,out); }
        else if path.extension().is_some_and(|x|x=="mcfunction") { out.push(path); }
    }
}
fn main() {
    let folder=env::args().nth(1).expect("mod content directory");
    let root=Path::new(&folder).join("data/atomic_age/function");
    let mut files=Vec::new();visit(&root,&mut files);
    let mut reg=Registries {permission:4,..Registries::default()};
    reg.functions=files.iter().map(|p|format!("atomic_age:{}",p.strip_prefix(&root).unwrap().with_extension("").to_string_lossy().replace('\\',"/"))).collect();
    reg.entity_types=["marker","tnt","item","player"].map(|x|format!("minecraft:{x}")).to_vec();
    reg.summonable=reg.entity_types.clone();
    reg.items=vec!["atomic_age:detonator".into()];
    for name in ["nuclear","singularity","cluster","thermobaric","drill","meteor"] {
        let id=format!("atomic_age:{name}_bomb");reg.blocks.insert(id.clone(),Vec::new());reg.items.push(id);
    }
    reg.blocks.insert("minecraft:air".into(),Vec::new());reg.block_tags.push("minecraft:air".into());
    reg.dimensions=["overworld","the_nether","the_end"].map(|x|format!("minecraft:{x}")).to_vec();
    reg.objectives=["atomic.use","atomic.time","atomic.cool","atomic.ray"].map(str::to_owned).to_vec();
    let d=vanilla::build();let mut total=0;let mut failures=0;
    for file in &files {
        for (n,line) in fs::read_to_string(file).unwrap().lines().enumerate() {
            let line=line.trim();if line.is_empty()||line.starts_with('#') {continue;}
            let parsed=d.parse(line,&reg);
            if let Err(error)=parsed.executable() {
                eprintln!("{}:{}: {:?}\n{}",file.display(),n+1,error,line);failures+=1;
            }
            total+=1;
        }
    }
    println!("Parsed {total} commands in {} functions; {failures} failures",files.len());
    assert_eq!(failures,0);
}
