//! Check the content item's component data with the pinned game's item loader.
use horizon_items::items::Items;
use horizon_world::loot::PackOverlay;
use serde_json::{Value,json};
use std::{env,fs,path::PathBuf};
fn main() {
    let file=env::args().nth(1).expect("detonator declaration");
    let item:Value=serde_json::from_slice(&fs::read(file).unwrap()).unwrap();
    let root=env::temp_dir().join(format!("atomic-item-check-{}",std::process::id()));
    fs::create_dir_all(root.join("data/minecraft/loot_table")).unwrap();
    let mut components=item["components"].clone();
    components["minecraft:max_stack_size"]=item["max_stack_size"].clone();
    fs::write(root.join("items.json"),serde_json::to_vec(&json!({"atomic_age:detonator":components})).unwrap()).unwrap();
    let items=Items::catalog(&root,&PackOverlay::NONE).unwrap();
    let info=items.get("atomic_age:detonator").unwrap();
    assert_eq!(info.max_stack,1);
    assert_eq!(info.consumable.as_ref().unwrap().ticks(),0);
    assert!(!info.consumable.as_ref().unwrap().particles);
    assert!(info.food.is_none(),"the detonator must not require hunger");
    assert_eq!(info.use_remainder.as_deref(),Some("atomic_age:detonator"));
    fs::remove_dir_all(PathBuf::from(root)).unwrap();
    println!("Pinned item loader: instant use, no hunger requirement, reusable remainder: verified");
}
