//! Development compiler: Rust choreography -> Minecraft data functions.
mod effects;
use effects::{Blast, Kind, Point, CHARGE, END, plan};
use std::{env,fs,path::Path};
fn relative(line: &str) -> String {
    if line.starts_with("execute positioned") {
        return "execute as @e[type=!player,type=!item,type=!tnt,type=!marker,tag=!atomic.blast,distance=2..18] at @s facing entity @e[type=marker,tag=atomic.blast,sort=nearest,limit=1] feet run tp @s ^ ^ ^0.65".into();
    }
    let mut words: Vec<String> = line.split_whitespace().map(str::to_owned).collect();
    let first = if words[0] == "playsound" { 4 } else { 2 };
    for word in &mut words[first..first+3] { *word=format!("~{word}"); }
    if words[0] == "playsound" { words[3]="@a[distance=..128]".into(); }
    words.join(" ")
}
fn main() {
    let out=env::args().nth(1).expect("output function directory");
    let root=Path::new(&out);
    for kind in Kind::ALL {
        let dir=root.join("timeline").join(kind.command());
        fs::create_dir_all(&dir).unwrap();
        let mut dispatch=Vec::new();
        for age in 0..=END {
            let b=Blast { at:Point{x:0.0,y:0.0,z:0.0},dimension:"minecraft:overworld".into(),kind,age };
            let mut lines: Vec<_>=plan(&b).iter().map(|line|relative(line)).collect();
            if age < CHARGE && age.is_multiple_of(20) {
                let seconds=(CHARGE-age)/20;
                lines.push(format!("title @a[distance=..96] actionbar {{\"translate\":\"atomic_age.countdown\",\"with\":[{{\"translate\":\"block.{}\"}},\"{seconds}\"]}}",kind.block_id().replace(':', ".")));
            }
            if age==CHARGE { lines.push("title @a[distance=..96] actionbar {\"translate\":\"atomic_age.detonation\"}".into()); }
            if lines.is_empty() { continue; }
            fs::write(dir.join(format!("{age}.mcfunction")),lines.join("\n")+"\n").unwrap();
            dispatch.push(format!("execute if score @s atomic.time matches {age} run function atomic_age:timeline/{}/{age}",kind.command()));
        }
        fs::write(root.join(format!("timeline/{}.mcfunction",kind.command())),dispatch.join("\n")+"\n").unwrap();
    }
}
#[cfg(test)] mod tests {
    use super::*;
    #[test] fn relative_position_preserves_fuse_and_spread() {
        assert_eq!(relative("summon minecraft:tnt 2.000 -4.000 0.000 {fuse:48s}"),"summon minecraft:tnt ~2.000 ~-4.000 ~0.000 {fuse:48s}");
        assert_eq!(relative("particle minecraft:flame 1.000 2.000 3.000 0.15 0.15 0.15 0.03 2 force"),"particle minecraft:flame ~1.000 ~2.000 ~3.000 0.15 0.15 0.15 0.03 2 force");
    }
}
