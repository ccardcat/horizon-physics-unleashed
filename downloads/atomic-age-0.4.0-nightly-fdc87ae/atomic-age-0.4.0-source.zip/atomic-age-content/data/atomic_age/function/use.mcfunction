scoreboard players set @s atomic.use 0
execute if score @s atomic.cool matches 1.. run title @s actionbar {"translate":"atomic_age.cooling"}
execute if score @s atomic.cool matches 0 run function atomic_age:target
