tag @s add atomic.hit
scoreboard players set @s atomic.cool 460
execute align xyz positioned ~0.5 ~1 ~0.5 run summon minecraft:marker ~ ~ ~ {Tags:["atomic.blast","atomic.singularity"]}
setblock ~ ~ ~ minecraft:air
