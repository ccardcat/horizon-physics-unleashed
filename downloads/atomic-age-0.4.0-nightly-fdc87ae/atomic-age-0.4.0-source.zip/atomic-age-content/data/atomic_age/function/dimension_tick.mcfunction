execute as @e[type=marker,tag=atomic.blast] at @s run function atomic_age:blast_tick
