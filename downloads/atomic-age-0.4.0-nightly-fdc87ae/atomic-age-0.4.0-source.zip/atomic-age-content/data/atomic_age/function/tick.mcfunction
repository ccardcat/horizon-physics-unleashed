scoreboard players add @a atomic.cool 0
scoreboard players remove @a[scores={atomic.cool=1..}] atomic.cool 1
execute as @a[scores={atomic.use=1..}] at @s run function atomic_age:use
execute in minecraft:overworld run function atomic_age:dimension_tick
execute in minecraft:the_nether run function atomic_age:dimension_tick
execute in minecraft:the_end run function atomic_age:dimension_tick
