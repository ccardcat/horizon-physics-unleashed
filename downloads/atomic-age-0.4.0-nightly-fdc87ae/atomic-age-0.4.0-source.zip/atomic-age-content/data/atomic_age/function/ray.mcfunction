execute if block ~ ~ ~ atomic_age:nuclear_bomb run function atomic_age:arm/nuke
execute if block ~ ~ ~ atomic_age:singularity_bomb run function atomic_age:arm/singularity
execute if block ~ ~ ~ atomic_age:cluster_bomb run function atomic_age:arm/cluster
execute if block ~ ~ ~ atomic_age:thermobaric_bomb run function atomic_age:arm/thermobaric
execute if block ~ ~ ~ atomic_age:drill_bomb run function atomic_age:arm/drill
execute if block ~ ~ ~ atomic_age:meteor_bomb run function atomic_age:arm/meteor
scoreboard players add @s atomic.ray 1
execute unless entity @s[tag=atomic.hit] if score @s atomic.ray matches ..191 if block ~ ~ ~ #minecraft:air positioned ^ ^ ^0.5 run function atomic_age:ray
