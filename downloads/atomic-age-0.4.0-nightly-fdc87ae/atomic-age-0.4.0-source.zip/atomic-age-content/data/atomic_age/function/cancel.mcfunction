execute in minecraft:overworld as @e[type=marker,tag=atomic.blast] run function atomic_age:cleanup
execute in minecraft:the_nether as @e[type=marker,tag=atomic.blast] run function atomic_age:cleanup
execute in minecraft:the_end as @e[type=marker,tag=atomic.blast] run function atomic_age:cleanup
