scoreboard objectives add atomic.use minecraft.used:atomic_age.detonator
scoreboard objectives add atomic.time dummy
scoreboard objectives add atomic.cool dummy
scoreboard objectives add atomic.ray dummy
