scoreboard players add @s atomic.time 0
execute if entity @s[tag=atomic.nuke] run function atomic_age:timeline/nuke
execute if entity @s[tag=atomic.singularity] run function atomic_age:timeline/singularity
execute if entity @s[tag=atomic.cluster] run function atomic_age:timeline/cluster
execute if entity @s[tag=atomic.thermobaric] run function atomic_age:timeline/thermobaric
execute if entity @s[tag=atomic.drill] run function atomic_age:timeline/drill
execute if entity @s[tag=atomic.meteor] run function atomic_age:timeline/meteor
scoreboard players add @s atomic.time 1
execute if score @s atomic.time matches 261.. run function atomic_age:cleanup
