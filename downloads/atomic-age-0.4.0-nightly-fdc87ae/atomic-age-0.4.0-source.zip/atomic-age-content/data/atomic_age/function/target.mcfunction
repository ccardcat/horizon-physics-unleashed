tag @s remove atomic.hit
scoreboard players set @s atomic.ray 0
execute anchored eyes positioned ^ ^ ^ run function atomic_age:ray
execute unless entity @s[tag=atomic.hit] run title @s actionbar {"translate":"atomic_age.target"}
tag @s remove atomic.hit
