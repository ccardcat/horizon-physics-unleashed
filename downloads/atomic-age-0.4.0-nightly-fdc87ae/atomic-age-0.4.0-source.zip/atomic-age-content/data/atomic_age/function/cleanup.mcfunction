scoreboard players reset @s atomic.time
kill @s
