summon minecraft:tnt ~23.500 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~16.617 ~0.000 ~16.617 {fuse:0s}
summon minecraft:tnt ~0.000 ~0.000 ~23.500 {fuse:0s}
summon minecraft:tnt ~-16.617 ~0.000 ~16.617 {fuse:0s}
summon minecraft:tnt ~-23.500 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-16.617 ~0.000 ~-16.617 {fuse:0s}
summon minecraft:tnt ~-0.000 ~0.000 ~-23.500 {fuse:0s}
summon minecraft:tnt ~16.617 ~0.000 ~-16.617 {fuse:0s}
particle minecraft:flame ~22.237 ~0.000 ~-10.284 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~24.400 ~0.000 ~2.212 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~20.025 ~0.000 ~14.116 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~10.284 ~0.000 ~22.237 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-2.212 ~0.000 ~24.400 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-14.116 ~0.000 ~20.025 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-22.237 ~0.000 ~10.284 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-24.400 ~0.000 ~-2.212 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-20.025 ~0.000 ~-14.116 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-10.284 ~0.000 ~-22.237 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~2.212 ~0.000 ~-24.400 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~14.116 ~0.000 ~-20.025 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~19.298 ~12.174 ~-8.925 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~21.175 ~12.174 ~1.920 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~17.378 ~12.174 ~12.250 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~8.925 ~12.174 ~19.298 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-1.920 ~12.174 ~21.175 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-12.250 ~12.174 ~17.378 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-19.298 ~12.174 ~8.925 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-21.175 ~12.174 ~-1.920 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-17.378 ~12.174 ~-12.250 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-8.925 ~12.174 ~-19.298 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~1.920 ~12.174 ~-21.175 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~12.250 ~12.174 ~-17.378 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~11.257 ~21.129 ~-5.206 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~12.352 ~21.129 ~1.120 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~10.137 ~21.129 ~7.146 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~5.206 ~21.129 ~11.257 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-1.120 ~21.129 ~12.352 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-7.146 ~21.129 ~10.137 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-11.257 ~21.129 ~5.206 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-12.352 ~21.129 ~-1.120 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-10.137 ~21.129 ~-7.146 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-5.206 ~21.129 ~-11.257 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~1.120 ~21.129 ~-12.352 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~7.146 ~21.129 ~-10.137 0.15 0.15 0.15 0.03 2 force
