particle minecraft:flame ~0.000 ~0.000 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~1.800 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~3.600 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~5.400 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~7.200 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~9.000 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~10.800 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~12.600 ~0.000 1 1 1 0.03 5 force
