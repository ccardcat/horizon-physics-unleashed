particle minecraft:flame ~0.000 ~22.999 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~24.799 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~26.599 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~28.399 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~30.199 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~31.999 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~33.799 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~35.599 ~0.000 1 1 1 0.03 5 force
