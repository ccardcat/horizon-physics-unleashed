summon minecraft:tnt ~13.045 ~0.000 ~33.553 {fuse:0s}
summon minecraft:tnt ~-14.502 ~0.000 ~32.950 {fuse:0s}
summon minecraft:tnt ~-33.553 ~0.000 ~13.045 {fuse:0s}
summon minecraft:tnt ~-32.950 ~0.000 ~-14.502 {fuse:0s}
summon minecraft:tnt ~-13.045 ~0.000 ~-33.553 {fuse:0s}
summon minecraft:tnt ~14.502 ~0.000 ~-32.950 {fuse:0s}
summon minecraft:tnt ~33.553 ~0.000 ~-13.045 {fuse:0s}
summon minecraft:tnt ~32.950 ~0.000 ~14.502 {fuse:0s}
particle minecraft:large_smoke ~0.000 ~15.000 ~0.000 2 2 2 0.03 20 force
particle minecraft:campfire_cosy_smoke ~-9.183 ~30.000 ~-14.897 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-0.504 ~30.000 ~-17.493 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~8.310 ~30.000 ~-15.401 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~14.897 ~30.000 ~-9.183 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~17.493 ~30.000 ~-0.504 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~15.401 ~30.000 ~8.310 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~9.183 ~30.000 ~14.897 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~0.504 ~30.000 ~17.493 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-8.310 ~30.000 ~15.401 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-14.897 ~30.000 ~9.183 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-17.493 ~30.000 ~0.504 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-15.401 ~30.000 ~-8.310 0.15 0.15 0.15 0.03 2 force
