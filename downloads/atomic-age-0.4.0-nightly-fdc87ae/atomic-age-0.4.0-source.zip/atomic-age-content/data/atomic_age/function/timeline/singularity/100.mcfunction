summon minecraft:tnt ~2.000 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~1.000 ~0.000 ~1.732 {fuse:0s}
summon minecraft:tnt ~-1.000 ~0.000 ~1.732 {fuse:0s}
summon minecraft:tnt ~-2.000 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-1.000 ~0.000 ~-1.732 {fuse:0s}
summon minecraft:tnt ~1.000 ~0.000 ~-1.732 {fuse:0s}
particle minecraft:flash{color:[1.0,0.85,0.5]} ~0.000 ~0.000 ~0.000 0 0 0 0.03 1 force
particle minecraft:explosion_emitter ~0.000 ~0.000 ~0.000 2 2 2 0.03 3 force
playsound minecraft:entity.generic.explode master @a[distance=..128] ~0.000 ~0.000 ~0.000 3 0.5
particle minecraft:portal ~16.334 ~2.000 ~-7.563 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~17.927 ~2.000 ~1.617 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~14.717 ~2.000 ~10.364 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~7.563 ~2.000 ~16.334 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-1.617 ~2.000 ~17.927 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-10.364 ~2.000 ~14.717 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-16.334 ~2.000 ~7.563 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-17.927 ~2.000 ~-1.617 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-14.717 ~2.000 ~-10.364 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-7.563 ~2.000 ~-16.334 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~1.617 ~2.000 ~-17.927 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~10.364 ~2.000 ~-14.717 0.15 0.15 0.15 0.03 2 force
particle minecraft:dragon_breath ~3.630 ~9.521 ~1.681 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~1.378 ~12.633 ~3.755 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~-1.681 ~12.445 ~3.630 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~-3.755 ~9.067 ~1.378 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~-3.630 ~4.479 ~-1.681 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~-1.378 ~1.367 ~-3.755 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~1.681 ~1.555 ~-3.630 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~3.755 ~4.933 ~-1.378 0.25 0.25 0.25 0.03 4 force
title @a[distance=..96] actionbar {"translate":"atomic_age.detonation"}
