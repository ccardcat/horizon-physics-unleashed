particle minecraft:portal ~12.000 ~0.300 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~10.392 ~0.300 ~6.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~6.000 ~0.300 ~10.392 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~0.000 ~0.300 ~12.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-6.000 ~0.300 ~10.392 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-10.392 ~0.300 ~6.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-12.000 ~0.300 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-10.392 ~0.300 ~-6.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-6.000 ~0.300 ~-10.392 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-0.000 ~0.300 ~-12.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~6.000 ~0.300 ~-10.392 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~10.392 ~0.300 ~-6.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~7.200 ~3.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~6.235 ~3.000 ~3.600 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~3.600 ~3.000 ~6.235 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~0.000 ~3.000 ~7.200 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-3.600 ~3.000 ~6.235 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-6.235 ~3.000 ~3.600 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-7.200 ~3.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-6.235 ~3.000 ~-3.600 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-3.600 ~3.000 ~-6.235 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-0.000 ~3.000 ~-7.200 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~3.600 ~3.000 ~-6.235 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~6.235 ~3.000 ~-3.600 0.15 0.15 0.15 0.03 2 force
playsound minecraft:block.note_block.pling master @a[distance=..128] ~0.000 ~0.000 ~0.000 3 0.6
execute as @e[type=!player,type=!item,type=!tnt,type=!marker,tag=!atomic.blast,distance=2..18] at @s facing entity @e[type=marker,tag=atomic.blast,sort=nearest,limit=1] feet run tp @s ^ ^ ^0.65
title @a[distance=..96] actionbar {"translate":"atomic_age.countdown","with":[{"translate":"block.atomic_age.singularity_bomb"},"5"]}
