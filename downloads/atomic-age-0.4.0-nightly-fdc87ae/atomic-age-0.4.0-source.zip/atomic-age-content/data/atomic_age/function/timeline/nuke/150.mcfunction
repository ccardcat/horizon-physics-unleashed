summon minecraft:tnt ~16.209 ~0.000 ~25.244 {fuse:0s}
summon minecraft:tnt ~-6.389 ~0.000 ~29.312 {fuse:0s}
summon minecraft:tnt ~-25.244 ~0.000 ~16.209 {fuse:0s}
summon minecraft:tnt ~-29.312 ~0.000 ~-6.389 {fuse:0s}
summon minecraft:tnt ~-16.209 ~0.000 ~-25.244 {fuse:0s}
summon minecraft:tnt ~6.389 ~0.000 ~-29.312 {fuse:0s}
summon minecraft:tnt ~25.244 ~0.000 ~-16.209 {fuse:0s}
summon minecraft:tnt ~29.312 ~0.000 ~6.389 {fuse:0s}
particle minecraft:large_smoke ~0.000 ~12.500 ~0.000 2 2 2 0.03 20 force
particle minecraft:campfire_cosy_smoke ~-11.070 ~25.000 ~-10.488 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-4.343 ~25.000 ~-14.618 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~3.548 ~25.000 ~-14.832 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~10.488 ~25.000 ~-11.070 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~14.618 ~25.000 ~-4.343 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~14.832 ~25.000 ~3.548 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~11.070 ~25.000 ~10.488 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~4.343 ~25.000 ~14.618 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-3.548 ~25.000 ~14.832 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-10.488 ~25.000 ~11.070 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-14.618 ~25.000 ~4.343 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-14.832 ~25.000 ~-3.548 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~35.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~30.311 ~1.000 ~17.500 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~17.500 ~1.000 ~30.311 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~0.000 ~1.000 ~35.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-17.500 ~1.000 ~30.311 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-30.311 ~1.000 ~17.500 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-35.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-30.311 ~1.000 ~-17.500 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-17.500 ~1.000 ~-30.311 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-0.000 ~1.000 ~-35.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~17.500 ~1.000 ~-30.311 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~30.311 ~1.000 ~-17.500 0.15 0.15 0.15 0.03 2 force
