summon minecraft:tnt ~16.721 ~0.000 ~17.217 {fuse:0s}
summon minecraft:tnt ~-0.350 ~0.000 ~23.997 {fuse:0s}
summon minecraft:tnt ~-17.217 ~0.000 ~16.721 {fuse:0s}
summon minecraft:tnt ~-23.997 ~0.000 ~-0.350 {fuse:0s}
summon minecraft:tnt ~-16.721 ~0.000 ~-17.217 {fuse:0s}
summon minecraft:tnt ~0.350 ~0.000 ~-23.997 {fuse:0s}
summon minecraft:tnt ~17.217 ~0.000 ~-16.721 {fuse:0s}
summon minecraft:tnt ~23.997 ~0.000 ~0.350 {fuse:0s}
particle minecraft:large_smoke ~0.000 ~10.000 ~0.000 2 2 2 0.03 20 force
particle minecraft:campfire_cosy_smoke ~-11.418 ~20.000 ~-6.214 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-6.782 ~20.000 ~-11.091 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-0.327 ~20.000 ~-12.996 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~6.214 ~20.000 ~-11.418 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~11.091 ~20.000 ~-6.782 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~12.996 ~20.000 ~-0.327 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~11.418 ~20.000 ~6.214 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~6.782 ~20.000 ~11.091 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~0.327 ~20.000 ~12.996 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-6.214 ~20.000 ~11.418 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-11.091 ~20.000 ~6.782 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-12.996 ~20.000 ~0.327 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~28.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~24.249 ~1.000 ~14.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~14.000 ~1.000 ~24.249 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~0.000 ~1.000 ~28.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-14.000 ~1.000 ~24.249 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-24.249 ~1.000 ~14.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-28.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-24.249 ~1.000 ~-14.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-14.000 ~1.000 ~-24.249 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-0.000 ~1.000 ~-28.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~14.000 ~1.000 ~-24.249 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~24.249 ~1.000 ~-14.000 0.15 0.15 0.15 0.03 2 force
