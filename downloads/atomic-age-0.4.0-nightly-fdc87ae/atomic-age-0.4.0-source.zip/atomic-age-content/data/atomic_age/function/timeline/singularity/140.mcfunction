summon minecraft:tnt ~12.000 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~6.000 ~0.000 ~10.392 {fuse:0s}
summon minecraft:tnt ~-6.000 ~0.000 ~10.392 {fuse:0s}
summon minecraft:tnt ~-12.000 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-6.000 ~0.000 ~-10.392 {fuse:0s}
summon minecraft:tnt ~6.000 ~0.000 ~-10.392 {fuse:0s}
particle minecraft:portal ~1.593 ~2.000 ~1.210 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~0.774 ~2.000 ~1.844 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-0.251 ~2.000 ~1.984 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-1.210 ~2.000 ~1.593 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-1.844 ~2.000 ~0.774 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-1.984 ~2.000 ~-0.251 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-1.593 ~2.000 ~-1.210 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-0.774 ~2.000 ~-1.844 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~0.251 ~2.000 ~-1.984 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~1.210 ~2.000 ~-1.593 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~1.844 ~2.000 ~-0.774 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~1.984 ~2.000 ~0.251 0.15 0.15 0.15 0.03 2 force
particle minecraft:dragon_breath ~3.185 ~3.371 ~-2.419 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~3.963 ~7.813 ~0.542 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~2.419 ~11.778 ~3.185 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~-0.542 ~12.945 ~3.963 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~-3.185 ~10.629 ~2.419 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~-3.963 ~6.187 ~-0.542 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~-2.419 ~2.222 ~-3.185 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~0.542 ~1.055 ~-3.963 0.25 0.25 0.25 0.03 4 force
