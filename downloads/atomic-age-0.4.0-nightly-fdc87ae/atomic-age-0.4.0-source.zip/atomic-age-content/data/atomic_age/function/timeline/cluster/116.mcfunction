summon minecraft:tnt ~-14.307 ~18.000 ~6.416 {fuse:48s}
summon minecraft:tnt ~-12.710 ~18.000 ~-9.182 {fuse:48s}
summon minecraft:tnt ~1.597 ~18.000 ~-15.598 {fuse:48s}
summon minecraft:tnt ~14.307 ~18.000 ~-6.416 {fuse:48s}
summon minecraft:tnt ~12.710 ~18.000 ~9.182 {fuse:48s}
summon minecraft:tnt ~-1.597 ~18.000 ~15.598 {fuse:48s}
