summon minecraft:tnt ~11.053 ~0.000 ~4.673 {fuse:0s}
summon minecraft:tnt ~4.511 ~0.000 ~11.120 {fuse:0s}
summon minecraft:tnt ~-4.673 ~0.000 ~11.053 {fuse:0s}
summon minecraft:tnt ~-11.120 ~0.000 ~4.511 {fuse:0s}
summon minecraft:tnt ~-11.053 ~0.000 ~-4.673 {fuse:0s}
summon minecraft:tnt ~-4.511 ~0.000 ~-11.120 {fuse:0s}
summon minecraft:tnt ~4.673 ~0.000 ~-11.053 {fuse:0s}
summon minecraft:tnt ~11.120 ~0.000 ~-4.511 {fuse:0s}
particle minecraft:large_smoke ~0.000 ~5.000 ~0.000 2 2 2 0.03 20 force
particle minecraft:campfire_cosy_smoke ~-8.498 ~10.000 ~0.184 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-7.451 ~10.000 ~-4.090 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-4.408 ~10.000 ~-7.268 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-0.184 ~10.000 ~-8.498 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~4.090 ~10.000 ~-7.451 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~7.268 ~10.000 ~-4.408 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~8.498 ~10.000 ~-0.184 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~7.451 ~10.000 ~4.090 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~4.408 ~10.000 ~7.268 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~0.184 ~10.000 ~8.498 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-4.090 ~10.000 ~7.451 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-7.268 ~10.000 ~4.408 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~14.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~12.124 ~1.000 ~7.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~7.000 ~1.000 ~12.124 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~0.000 ~1.000 ~14.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-7.000 ~1.000 ~12.124 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-12.124 ~1.000 ~7.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-14.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-12.124 ~1.000 ~-7.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-7.000 ~1.000 ~-12.124 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-0.000 ~1.000 ~-14.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~7.000 ~1.000 ~-12.124 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~12.124 ~1.000 ~-7.000 0.15 0.15 0.15 0.03 2 force
