particle minecraft:flame ~0.000 ~47.761 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~49.561 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~51.361 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~53.161 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~54.961 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~56.761 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~58.561 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~60.361 ~0.000 1 1 1 0.03 5 force
