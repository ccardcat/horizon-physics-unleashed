summon minecraft:tnt ~1.500 ~-8.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-0.750 ~-8.000 ~1.299 {fuse:0s}
summon minecraft:tnt ~-0.750 ~-8.000 ~-1.299 {fuse:0s}
