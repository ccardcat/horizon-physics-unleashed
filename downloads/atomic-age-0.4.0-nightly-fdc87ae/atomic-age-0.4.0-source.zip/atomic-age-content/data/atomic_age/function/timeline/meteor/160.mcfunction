particle minecraft:flame ~0.000 ~4.747 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~6.547 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~8.347 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~10.147 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~11.947 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~13.747 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~15.547 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~17.347 ~0.000 1 1 1 0.03 5 force
