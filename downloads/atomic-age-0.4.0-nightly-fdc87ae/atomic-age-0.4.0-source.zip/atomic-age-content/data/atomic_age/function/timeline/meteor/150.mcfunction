particle minecraft:flame ~0.000 ~17.296 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~19.096 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~20.896 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~22.696 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~24.496 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~26.296 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~28.096 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~29.896 ~0.000 1 1 1 0.03 5 force
