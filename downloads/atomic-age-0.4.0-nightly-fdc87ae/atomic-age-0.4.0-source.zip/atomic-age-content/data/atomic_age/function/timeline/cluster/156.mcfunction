summon minecraft:tnt ~-34.722 ~18.000 ~-3.316 {fuse:48s}
summon minecraft:tnt ~-14.489 ~18.000 ~-31.728 {fuse:48s}
summon minecraft:tnt ~20.233 ~18.000 ~-28.412 {fuse:48s}
summon minecraft:tnt ~34.722 ~18.000 ~3.316 {fuse:48s}
summon minecraft:tnt ~14.489 ~18.000 ~31.728 {fuse:48s}
summon minecraft:tnt ~-20.233 ~18.000 ~28.412 {fuse:48s}
