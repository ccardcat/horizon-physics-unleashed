summon minecraft:tnt ~10.600 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~7.495 ~0.000 ~7.495 {fuse:0s}
summon minecraft:tnt ~0.000 ~0.000 ~10.600 {fuse:0s}
summon minecraft:tnt ~-7.495 ~0.000 ~7.495 {fuse:0s}
summon minecraft:tnt ~-10.600 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-7.495 ~0.000 ~-7.495 {fuse:0s}
summon minecraft:tnt ~-0.000 ~0.000 ~-10.600 {fuse:0s}
summon minecraft:tnt ~7.495 ~0.000 ~-7.495 {fuse:0s}
particle minecraft:flame ~-0.356 ~0.000 ~-10.994 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~5.189 ~0.000 ~-9.699 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~9.343 ~0.000 ~-5.806 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~10.994 ~0.000 ~-0.356 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~9.699 ~0.000 ~5.189 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~5.806 ~0.000 ~9.343 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.356 ~0.000 ~10.994 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-5.189 ~0.000 ~9.699 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-9.343 ~0.000 ~5.806 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-10.994 ~0.000 ~0.356 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-9.699 ~0.000 ~-5.189 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-5.806 ~0.000 ~-9.343 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.309 ~5.466 ~-9.541 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~4.503 ~5.466 ~-8.417 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~8.108 ~5.466 ~-5.038 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~9.541 ~5.466 ~-0.309 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~8.417 ~5.466 ~4.503 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~5.038 ~5.466 ~8.108 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.309 ~5.466 ~9.541 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-4.503 ~5.466 ~8.417 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-8.108 ~5.466 ~5.038 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-9.541 ~5.466 ~0.309 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-8.417 ~5.466 ~-4.503 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-5.038 ~5.466 ~-8.108 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.180 ~9.486 ~-5.566 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~2.627 ~9.486 ~-4.910 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~4.730 ~9.486 ~-2.939 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~5.566 ~9.486 ~-0.180 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~4.910 ~9.486 ~2.627 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~2.939 ~9.486 ~4.730 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.180 ~9.486 ~5.566 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-2.627 ~9.486 ~4.910 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-4.730 ~9.486 ~2.939 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-5.566 ~9.486 ~0.180 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-4.910 ~9.486 ~-2.627 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-2.939 ~9.486 ~-4.730 0.15 0.15 0.15 0.03 2 force
