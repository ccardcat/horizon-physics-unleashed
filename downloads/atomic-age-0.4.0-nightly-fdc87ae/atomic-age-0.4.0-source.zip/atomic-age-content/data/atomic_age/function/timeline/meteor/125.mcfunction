particle minecraft:flame ~0.000 ~40.969 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~42.769 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~44.569 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~46.369 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~48.169 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~49.969 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~51.769 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~53.569 ~0.000 1 1 1 0.03 5 force
