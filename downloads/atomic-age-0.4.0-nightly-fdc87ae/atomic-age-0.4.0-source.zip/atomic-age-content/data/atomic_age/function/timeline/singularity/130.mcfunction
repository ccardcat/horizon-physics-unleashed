summon minecraft:tnt ~9.500 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~4.750 ~0.000 ~8.227 {fuse:0s}
summon minecraft:tnt ~-4.750 ~0.000 ~8.227 {fuse:0s}
summon minecraft:tnt ~-9.500 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-4.750 ~0.000 ~-8.227 {fuse:0s}
summon minecraft:tnt ~4.750 ~0.000 ~-8.227 {fuse:0s}
particle minecraft:portal ~-2.219 ~2.000 ~5.575 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-4.709 ~2.000 ~3.719 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-5.937 ~2.000 ~0.866 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-5.575 ~2.000 ~-2.219 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-3.719 ~2.000 ~-4.709 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-0.866 ~2.000 ~-5.937 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~2.219 ~2.000 ~-5.575 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~4.709 ~2.000 ~-3.719 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~5.937 ~2.000 ~-0.866 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~5.575 ~2.000 ~2.219 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~3.719 ~2.000 ~4.709 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~0.866 ~2.000 ~5.937 0.15 0.15 0.15 0.03 2 force
particle minecraft:dragon_breath ~-1.479 ~1.425 ~-3.716 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~1.582 ~1.489 ~-3.674 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~3.716 ~4.781 ~-1.479 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~3.674 ~9.373 ~1.582 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~1.479 ~12.575 ~3.716 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~-1.582 ~12.511 ~3.674 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~-3.716 ~9.219 ~1.479 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~-3.674 ~4.627 ~-1.582 0.25 0.25 0.25 0.03 4 force
