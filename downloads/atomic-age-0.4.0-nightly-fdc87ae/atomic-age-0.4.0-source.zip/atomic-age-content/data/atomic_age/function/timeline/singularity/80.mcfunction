particle minecraft:portal ~-2.244 ~0.300 ~-3.311 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-0.288 ~0.300 ~-3.990 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~1.746 ~0.300 ~-3.599 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~3.311 ~0.300 ~-2.244 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~3.990 ~0.300 ~-0.288 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~3.599 ~0.300 ~1.746 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~2.244 ~0.300 ~3.311 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~0.288 ~0.300 ~3.990 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-1.746 ~0.300 ~3.599 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-3.311 ~0.300 ~2.244 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-3.990 ~0.300 ~0.288 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-3.599 ~0.300 ~-1.746 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-1.346 ~3.000 ~1.987 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-2.159 ~3.000 ~1.047 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-2.394 ~3.000 ~-0.173 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-1.987 ~3.000 ~-1.346 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-1.047 ~3.000 ~-2.159 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~0.173 ~3.000 ~-2.394 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~1.346 ~3.000 ~-1.987 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~2.159 ~3.000 ~-1.047 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~2.394 ~3.000 ~0.173 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~1.987 ~3.000 ~1.346 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~1.047 ~3.000 ~2.159 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-0.173 ~3.000 ~2.394 0.15 0.15 0.15 0.03 2 force
playsound minecraft:block.note_block.pling master @a[distance=..128] ~0.000 ~0.000 ~0.000 3 1.4000001
execute as @e[type=!player,type=!item,type=!tnt,type=!marker,tag=!atomic.blast,distance=2..18] at @s facing entity @e[type=marker,tag=atomic.blast,sort=nearest,limit=1] feet run tp @s ^ ^ ^0.65
title @a[distance=..96] actionbar {"translate":"atomic_age.countdown","with":[{"translate":"block.atomic_age.singularity_bomb"},"1"]}
