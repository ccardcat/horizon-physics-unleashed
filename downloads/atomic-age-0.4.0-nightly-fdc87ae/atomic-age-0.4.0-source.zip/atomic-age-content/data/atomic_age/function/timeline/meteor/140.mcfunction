particle minecraft:flame ~0.000 ~28.267 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~30.067 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~31.867 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~33.667 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~35.467 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~37.267 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~39.067 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~40.867 ~0.000 1 1 1 0.03 5 force
