summon minecraft:tnt ~19.600 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~9.800 ~0.000 ~16.974 {fuse:0s}
summon minecraft:tnt ~-9.800 ~0.000 ~16.974 {fuse:0s}
summon minecraft:tnt ~-19.600 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-9.800 ~0.000 ~-16.974 {fuse:0s}
summon minecraft:tnt ~9.800 ~0.000 ~-16.974 {fuse:0s}
