summon minecraft:tnt ~1.000 ~48.000 ~0.000 {fuse:70s}
summon minecraft:tnt ~0.000 ~48.000 ~1.000 {fuse:70s}
summon minecraft:tnt ~-1.000 ~48.000 ~0.000 {fuse:70s}
summon minecraft:tnt ~-0.000 ~48.000 ~-1.000 {fuse:70s}
particle minecraft:flash{color:[1.0,0.85,0.5]} ~0.000 ~0.000 ~0.000 0 0 0 0.03 1 force
particle minecraft:explosion_emitter ~0.000 ~0.000 ~0.000 2 2 2 0.03 3 force
playsound minecraft:entity.generic.explode master @a[distance=..128] ~0.000 ~0.000 ~0.000 3 0.5
particle minecraft:flame ~0.000 ~48.000 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~49.800 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~51.600 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~53.400 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~55.200 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~57.000 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~58.800 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~60.600 ~0.000 1 1 1 0.03 5 force
title @a[distance=..96] actionbar {"translate":"atomic_age.detonation"}
