summon minecraft:tnt ~1.500 ~-20.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-0.750 ~-20.000 ~1.299 {fuse:0s}
summon minecraft:tnt ~-0.750 ~-20.000 ~-1.299 {fuse:0s}
particle minecraft:explosion ~0.000 ~-20.000 ~0.000 1 1 1 0.03 2 force
particle minecraft:electric_spark ~4.600 ~10.000 ~0.000 0.2 0.2 0.2 0.03 4 force
particle minecraft:electric_spark ~3.253 ~10.000 ~3.253 0.2 0.2 0.2 0.03 4 force
particle minecraft:electric_spark ~0.000 ~10.000 ~4.600 0.2 0.2 0.2 0.03 4 force
particle minecraft:electric_spark ~-3.253 ~10.000 ~3.253 0.2 0.2 0.2 0.03 4 force
particle minecraft:electric_spark ~-4.600 ~10.000 ~0.000 0.2 0.2 0.2 0.03 4 force
particle minecraft:electric_spark ~-3.253 ~10.000 ~-3.253 0.2 0.2 0.2 0.03 4 force
particle minecraft:electric_spark ~-0.000 ~10.000 ~-4.600 0.2 0.2 0.2 0.03 4 force
particle minecraft:electric_spark ~3.253 ~10.000 ~-3.253 0.2 0.2 0.2 0.03 4 force
particle minecraft:large_smoke ~0.000 ~0.000 ~0.000 3 3 3 0.03 16 force
