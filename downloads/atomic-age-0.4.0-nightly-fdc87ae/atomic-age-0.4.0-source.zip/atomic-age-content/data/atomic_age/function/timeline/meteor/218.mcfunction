summon minecraft:tnt ~35.200 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~17.600 ~0.000 ~30.484 {fuse:0s}
summon minecraft:tnt ~-17.600 ~0.000 ~30.484 {fuse:0s}
summon minecraft:tnt ~-35.200 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-17.600 ~0.000 ~-30.484 {fuse:0s}
summon minecraft:tnt ~17.600 ~0.000 ~-30.484 {fuse:0s}
