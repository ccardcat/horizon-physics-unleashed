particle minecraft:flame ~0.000 ~48.369 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~50.169 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~51.969 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~53.769 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~55.569 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~57.369 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~59.169 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~60.969 ~0.000 1 1 1 0.03 5 force
