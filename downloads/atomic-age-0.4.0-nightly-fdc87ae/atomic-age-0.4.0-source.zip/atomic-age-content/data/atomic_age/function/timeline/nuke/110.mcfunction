summon minecraft:tnt ~5.880 ~0.000 ~1.192 {fuse:0s}
summon minecraft:tnt ~3.315 ~0.000 ~5.001 {fuse:0s}
summon minecraft:tnt ~-1.192 ~0.000 ~5.880 {fuse:0s}
summon minecraft:tnt ~-5.001 ~0.000 ~3.315 {fuse:0s}
summon minecraft:tnt ~-5.880 ~0.000 ~-1.192 {fuse:0s}
summon minecraft:tnt ~-3.315 ~0.000 ~-5.001 {fuse:0s}
summon minecraft:tnt ~1.192 ~0.000 ~-5.880 {fuse:0s}
summon minecraft:tnt ~5.001 ~0.000 ~-3.315 {fuse:0s}
particle minecraft:large_smoke ~0.000 ~2.500 ~0.000 2 2 2 0.03 20 force
particle minecraft:campfire_cosy_smoke ~-6.004 ~5.000 ~1.737 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-6.068 ~5.000 ~-1.498 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-4.506 ~5.000 ~-4.331 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-1.737 ~5.000 ~-6.004 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~1.498 ~5.000 ~-6.068 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~4.331 ~5.000 ~-4.506 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~6.004 ~5.000 ~-1.737 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~6.068 ~5.000 ~1.498 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~4.506 ~5.000 ~4.331 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~1.737 ~5.000 ~6.004 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-1.498 ~5.000 ~6.068 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-4.331 ~5.000 ~4.506 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~7.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~6.062 ~1.000 ~3.500 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~3.500 ~1.000 ~6.062 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~0.000 ~1.000 ~7.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-3.500 ~1.000 ~6.062 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-6.062 ~1.000 ~3.500 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-7.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-6.062 ~1.000 ~-3.500 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-3.500 ~1.000 ~-6.062 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-0.000 ~1.000 ~-7.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~3.500 ~1.000 ~-6.062 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~6.062 ~1.000 ~-3.500 0.15 0.15 0.15 0.03 2 force
