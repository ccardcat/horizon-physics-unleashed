summon minecraft:tnt ~1.500 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-0.750 ~0.000 ~1.299 {fuse:0s}
summon minecraft:tnt ~-0.750 ~0.000 ~-1.299 {fuse:0s}
particle minecraft:flash{color:[1.0,0.85,0.5]} ~0.000 ~0.000 ~0.000 0 0 0 0.03 1 force
particle minecraft:explosion_emitter ~0.000 ~0.000 ~0.000 2 2 2 0.03 3 force
playsound minecraft:entity.generic.explode master @a[distance=..128] ~0.000 ~0.000 ~0.000 3 0.5
particle minecraft:explosion ~0.000 ~0.000 ~0.000 1 1 1 0.03 2 force
particle minecraft:electric_spark ~3.000 ~0.000 ~0.000 0.2 0.2 0.2 0.03 4 force
particle minecraft:electric_spark ~2.121 ~0.000 ~2.121 0.2 0.2 0.2 0.03 4 force
particle minecraft:electric_spark ~0.000 ~0.000 ~3.000 0.2 0.2 0.2 0.03 4 force
particle minecraft:electric_spark ~-2.121 ~0.000 ~2.121 0.2 0.2 0.2 0.03 4 force
particle minecraft:electric_spark ~-3.000 ~0.000 ~0.000 0.2 0.2 0.2 0.03 4 force
particle minecraft:electric_spark ~-2.121 ~0.000 ~-2.121 0.2 0.2 0.2 0.03 4 force
particle minecraft:electric_spark ~-0.000 ~0.000 ~-3.000 0.2 0.2 0.2 0.03 4 force
particle minecraft:electric_spark ~2.121 ~0.000 ~-2.121 0.2 0.2 0.2 0.03 4 force
particle minecraft:large_smoke ~0.000 ~0.000 ~0.000 3 3 3 0.03 16 force
title @a[distance=..96] actionbar {"translate":"atomic_age.detonation"}
