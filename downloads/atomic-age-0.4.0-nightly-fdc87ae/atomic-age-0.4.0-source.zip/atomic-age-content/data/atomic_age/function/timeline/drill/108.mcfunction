summon minecraft:tnt ~1.500 ~-4.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-0.750 ~-4.000 ~1.299 {fuse:0s}
summon minecraft:tnt ~-0.750 ~-4.000 ~-1.299 {fuse:0s}
