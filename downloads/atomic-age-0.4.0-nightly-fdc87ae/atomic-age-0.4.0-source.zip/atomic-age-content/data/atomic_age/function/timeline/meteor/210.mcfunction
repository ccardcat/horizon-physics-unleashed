summon minecraft:tnt ~30.000 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~15.000 ~0.000 ~25.981 {fuse:0s}
summon minecraft:tnt ~-15.000 ~0.000 ~25.981 {fuse:0s}
summon minecraft:tnt ~-30.000 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-15.000 ~0.000 ~-25.981 {fuse:0s}
summon minecraft:tnt ~15.000 ~0.000 ~-25.981 {fuse:0s}
particle minecraft:cloud ~-12.639 ~1.000 ~18.615 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-20.253 ~1.000 ~9.802 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-22.440 ~1.000 ~-1.638 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-18.615 ~1.000 ~-12.639 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-9.802 ~1.000 ~-20.253 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~1.638 ~1.000 ~-22.440 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~12.639 ~1.000 ~-18.615 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~20.253 ~1.000 ~-9.802 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~22.440 ~1.000 ~1.638 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~18.615 ~1.000 ~12.639 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~9.802 ~1.000 ~20.253 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-1.638 ~1.000 ~22.440 0.15 0.15 0.15 0.03 2 force
particle minecraft:lava ~0.000 ~0.000 ~0.000 4 4 4 0.03 8 force
particle minecraft:large_smoke ~0.000 ~18.000 ~0.000 4 4 4 0.03 20 force
