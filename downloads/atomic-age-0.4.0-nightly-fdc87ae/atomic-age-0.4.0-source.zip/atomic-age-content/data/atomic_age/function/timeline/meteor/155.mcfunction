particle minecraft:flame ~0.000 ~11.200 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~13.000 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~14.800 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~16.600 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~18.400 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~20.200 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~22.000 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~23.800 ~0.000 1 1 1 0.03 5 force
