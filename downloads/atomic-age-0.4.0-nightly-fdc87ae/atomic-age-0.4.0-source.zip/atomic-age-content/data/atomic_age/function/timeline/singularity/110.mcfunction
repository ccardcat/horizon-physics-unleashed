summon minecraft:tnt ~4.500 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~2.250 ~0.000 ~3.897 {fuse:0s}
summon minecraft:tnt ~-2.250 ~0.000 ~3.897 {fuse:0s}
summon minecraft:tnt ~-4.500 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-2.250 ~0.000 ~-3.897 {fuse:0s}
summon minecraft:tnt ~2.250 ~0.000 ~-3.897 {fuse:0s}
particle minecraft:portal ~-2.270 ~2.000 ~-13.815 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~4.942 ~2.000 ~-13.099 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~10.829 ~2.000 ~-8.873 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~13.815 ~2.000 ~-2.270 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~13.099 ~2.000 ~4.942 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~8.873 ~2.000 ~10.829 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~2.270 ~2.000 ~13.815 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-4.942 ~2.000 ~13.099 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-10.829 ~2.000 ~8.873 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-13.815 ~2.000 ~2.270 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-13.099 ~2.000 ~-4.942 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-8.873 ~2.000 ~-10.829 0.15 0.15 0.15 0.03 2 force
particle minecraft:dragon_breath ~-0.648 ~12.921 ~3.947 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~-3.250 ~10.499 ~2.332 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~-3.947 ~6.027 ~-0.648 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~-2.332 ~2.126 ~-3.250 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~0.648 ~1.079 ~-3.947 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~3.250 ~3.501 ~-2.332 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~3.947 ~7.973 ~0.648 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~2.332 ~11.874 ~3.250 0.25 0.25 0.25 0.03 4 force
