summon minecraft:tnt ~4.000 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~2.000 ~0.000 ~3.464 {fuse:0s}
summon minecraft:tnt ~-2.000 ~0.000 ~3.464 {fuse:0s}
summon minecraft:tnt ~-4.000 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-2.000 ~0.000 ~-3.464 {fuse:0s}
summon minecraft:tnt ~2.000 ~0.000 ~-3.464 {fuse:0s}
particle minecraft:cloud ~-2.485 ~1.000 ~-0.272 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-2.016 ~1.000 ~-1.478 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-1.007 ~1.000 ~-2.288 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~0.272 ~1.000 ~-2.485 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~1.478 ~1.000 ~-2.016 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~2.288 ~1.000 ~-1.007 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~2.485 ~1.000 ~0.272 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~2.016 ~1.000 ~1.478 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~1.007 ~1.000 ~2.288 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-0.272 ~1.000 ~2.485 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-1.478 ~1.000 ~2.016 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-2.288 ~1.000 ~1.007 0.15 0.15 0.15 0.03 2 force
particle minecraft:lava ~0.000 ~0.000 ~0.000 4 4 4 0.03 8 force
particle minecraft:large_smoke ~0.000 ~2.000 ~0.000 4 4 4 0.03 20 force
