particle minecraft:flame ~0.000 ~43.980 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~45.780 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~47.580 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~49.380 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~51.180 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~52.980 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~54.780 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~56.580 ~0.000 1 1 1 0.03 5 force
