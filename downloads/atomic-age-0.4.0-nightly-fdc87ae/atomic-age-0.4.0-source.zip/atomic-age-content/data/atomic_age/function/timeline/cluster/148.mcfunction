summon minecraft:tnt ~-9.351 ~18.000 ~29.598 {fuse:48s}
summon minecraft:tnt ~-30.308 ~18.000 ~6.701 {fuse:48s}
summon minecraft:tnt ~-20.957 ~18.000 ~-22.897 {fuse:48s}
summon minecraft:tnt ~9.351 ~18.000 ~-29.598 {fuse:48s}
summon minecraft:tnt ~30.308 ~18.000 ~-6.701 {fuse:48s}
summon minecraft:tnt ~20.957 ~18.000 ~22.897 {fuse:48s}
