summon minecraft:tnt ~23.648 ~18.000 ~13.440 {fuse:48s}
summon minecraft:tnt ~0.185 ~18.000 ~27.199 {fuse:48s}
summon minecraft:tnt ~-23.463 ~18.000 ~13.759 {fuse:48s}
summon minecraft:tnt ~-23.648 ~18.000 ~-13.440 {fuse:48s}
summon minecraft:tnt ~-0.185 ~18.000 ~-27.199 {fuse:48s}
summon minecraft:tnt ~23.463 ~18.000 ~-13.759 {fuse:48s}
particle minecraft:flame ~20.705 ~18.000 ~-15.726 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~25.794 ~18.000 ~-3.266 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~23.971 ~18.000 ~10.068 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~15.726 ~18.000 ~20.705 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~3.266 ~18.000 ~25.794 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-10.068 ~18.000 ~23.971 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-20.705 ~18.000 ~15.726 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-25.794 ~18.000 ~3.266 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-23.971 ~18.000 ~-10.068 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-15.726 ~18.000 ~-20.705 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-3.266 ~18.000 ~-25.794 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~10.068 ~18.000 ~-23.971 0.15 0.15 0.15 0.03 2 force
particle minecraft:large_smoke ~0.000 ~0.000 ~0.000 8 8 8 0.03 12 force
