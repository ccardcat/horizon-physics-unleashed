summon minecraft:tnt ~27.800 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~19.658 ~0.000 ~19.658 {fuse:0s}
summon minecraft:tnt ~0.000 ~0.000 ~27.800 {fuse:0s}
summon minecraft:tnt ~-19.658 ~0.000 ~19.658 {fuse:0s}
summon minecraft:tnt ~-27.800 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-19.658 ~0.000 ~-19.658 {fuse:0s}
summon minecraft:tnt ~-0.000 ~0.000 ~-27.800 {fuse:0s}
summon minecraft:tnt ~19.658 ~0.000 ~-19.658 {fuse:0s}
particle minecraft:flame ~28.973 ~0.000 ~-1.252 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~25.717 ~0.000 ~13.402 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~15.571 ~0.000 ~24.465 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~1.252 ~0.000 ~28.973 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-13.402 ~0.000 ~25.717 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-24.465 ~0.000 ~15.571 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-28.973 ~0.000 ~1.252 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-25.717 ~0.000 ~-13.402 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-15.571 ~0.000 ~-24.465 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-1.252 ~0.000 ~-28.973 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~13.402 ~0.000 ~-25.717 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~24.465 ~0.000 ~-15.571 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~25.143 ~14.410 ~-1.086 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~22.318 ~14.410 ~11.631 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~13.513 ~14.410 ~21.231 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~1.086 ~14.410 ~25.143 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-11.631 ~14.410 ~22.318 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-21.231 ~14.410 ~13.513 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-25.143 ~14.410 ~1.086 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-22.318 ~14.410 ~-11.631 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-13.513 ~14.410 ~-21.231 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-1.086 ~14.410 ~-25.143 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~11.631 ~14.410 ~-22.318 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~21.231 ~14.410 ~-13.513 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~14.667 ~25.010 ~-0.634 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~13.019 ~25.010 ~6.784 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~7.882 ~25.010 ~12.385 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.634 ~25.010 ~14.667 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-6.784 ~25.010 ~13.019 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-12.385 ~25.010 ~7.882 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-14.667 ~25.010 ~0.634 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-13.019 ~25.010 ~-6.784 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-7.882 ~25.010 ~-12.385 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.634 ~25.010 ~-14.667 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~6.784 ~25.010 ~-13.019 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~12.385 ~25.010 ~-7.882 0.15 0.15 0.15 0.03 2 force
