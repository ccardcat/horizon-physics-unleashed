summon minecraft:tnt ~9.200 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~4.600 ~0.000 ~7.967 {fuse:0s}
summon minecraft:tnt ~-4.600 ~0.000 ~7.967 {fuse:0s}
summon minecraft:tnt ~-9.200 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-4.600 ~0.000 ~-7.967 {fuse:0s}
summon minecraft:tnt ~4.600 ~0.000 ~-7.967 {fuse:0s}
