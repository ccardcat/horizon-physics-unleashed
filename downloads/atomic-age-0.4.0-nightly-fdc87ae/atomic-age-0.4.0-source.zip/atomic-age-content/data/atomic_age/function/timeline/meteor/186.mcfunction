summon minecraft:tnt ~14.400 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~7.200 ~0.000 ~12.471 {fuse:0s}
summon minecraft:tnt ~-7.200 ~0.000 ~12.471 {fuse:0s}
summon minecraft:tnt ~-14.400 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-7.200 ~0.000 ~-12.471 {fuse:0s}
summon minecraft:tnt ~7.200 ~0.000 ~-12.471 {fuse:0s}
