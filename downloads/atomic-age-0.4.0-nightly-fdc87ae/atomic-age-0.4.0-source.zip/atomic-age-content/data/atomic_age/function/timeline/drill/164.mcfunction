summon minecraft:tnt ~1.500 ~-32.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-0.750 ~-32.000 ~1.299 {fuse:0s}
summon minecraft:tnt ~-0.750 ~-32.000 ~-1.299 {fuse:0s}
