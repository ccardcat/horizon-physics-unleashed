summon minecraft:tnt ~14.856 ~0.000 ~10.164 {fuse:0s}
summon minecraft:tnt ~3.318 ~0.000 ~17.692 {fuse:0s}
summon minecraft:tnt ~-10.164 ~0.000 ~14.856 {fuse:0s}
summon minecraft:tnt ~-17.692 ~0.000 ~3.318 {fuse:0s}
summon minecraft:tnt ~-14.856 ~0.000 ~-10.164 {fuse:0s}
summon minecraft:tnt ~-3.318 ~0.000 ~-17.692 {fuse:0s}
summon minecraft:tnt ~10.164 ~0.000 ~-14.856 {fuse:0s}
summon minecraft:tnt ~17.692 ~0.000 ~-3.318 {fuse:0s}
particle minecraft:large_smoke ~0.000 ~7.500 ~0.000 2 2 2 0.03 20 force
particle minecraft:campfire_cosy_smoke ~-10.446 ~15.000 ~-2.539 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-7.777 ~15.000 ~-7.422 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-3.024 ~15.000 ~-10.316 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~2.539 ~15.000 ~-10.446 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~7.422 ~15.000 ~-7.777 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~10.316 ~15.000 ~-3.024 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~10.446 ~15.000 ~2.539 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~7.777 ~15.000 ~7.422 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~3.024 ~15.000 ~10.316 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-2.539 ~15.000 ~10.446 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-7.422 ~15.000 ~7.777 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-10.316 ~15.000 ~3.024 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~21.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~18.187 ~1.000 ~10.500 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~10.500 ~1.000 ~18.187 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~0.000 ~1.000 ~21.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-10.500 ~1.000 ~18.187 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-18.187 ~1.000 ~10.500 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-21.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-18.187 ~1.000 ~-10.500 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-10.500 ~1.000 ~-18.187 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~-0.000 ~1.000 ~-21.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~10.500 ~1.000 ~-18.187 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~18.187 ~1.000 ~-10.500 0.15 0.15 0.15 0.03 2 force
