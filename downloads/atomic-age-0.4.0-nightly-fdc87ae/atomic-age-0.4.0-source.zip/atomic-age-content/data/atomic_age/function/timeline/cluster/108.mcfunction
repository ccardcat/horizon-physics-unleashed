summon minecraft:tnt ~2.477 ~18.000 ~11.578 {fuse:48s}
summon minecraft:tnt ~-8.788 ~18.000 ~7.934 {fuse:48s}
summon minecraft:tnt ~-11.265 ~18.000 ~-3.643 {fuse:48s}
summon minecraft:tnt ~-2.477 ~18.000 ~-11.578 {fuse:48s}
summon minecraft:tnt ~8.788 ~18.000 ~-7.934 {fuse:48s}
summon minecraft:tnt ~11.265 ~18.000 ~3.643 {fuse:48s}
