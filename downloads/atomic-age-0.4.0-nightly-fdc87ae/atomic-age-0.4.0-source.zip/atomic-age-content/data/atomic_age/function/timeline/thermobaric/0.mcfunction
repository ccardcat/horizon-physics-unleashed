particle minecraft:flame ~12.000 ~0.300 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~10.392 ~0.300 ~6.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~6.000 ~0.300 ~10.392 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.000 ~0.300 ~12.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-6.000 ~0.300 ~10.392 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-10.392 ~0.300 ~6.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-12.000 ~0.300 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-10.392 ~0.300 ~-6.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-6.000 ~0.300 ~-10.392 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.000 ~0.300 ~-12.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~6.000 ~0.300 ~-10.392 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~10.392 ~0.300 ~-6.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~7.200 ~3.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~6.235 ~3.000 ~3.600 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~3.600 ~3.000 ~6.235 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~0.000 ~3.000 ~7.200 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-3.600 ~3.000 ~6.235 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-6.235 ~3.000 ~3.600 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-7.200 ~3.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-6.235 ~3.000 ~-3.600 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-3.600 ~3.000 ~-6.235 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-0.000 ~3.000 ~-7.200 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~3.600 ~3.000 ~-6.235 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~6.235 ~3.000 ~-3.600 0.15 0.15 0.15 0.03 2 force
playsound minecraft:block.note_block.pling master @a[distance=..128] ~0.000 ~0.000 ~0.000 3 0.6
title @a[distance=..96] actionbar {"translate":"atomic_age.countdown","with":[{"translate":"block.atomic_age.thermobaric_bomb"},"5"]}
