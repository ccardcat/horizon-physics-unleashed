summon minecraft:tnt ~15.536 ~18.000 ~-17.444 {fuse:48s}
summon minecraft:tnt ~22.876 ~18.000 ~4.733 {fuse:48s}
summon minecraft:tnt ~7.339 ~18.000 ~22.177 {fuse:48s}
summon minecraft:tnt ~-15.536 ~18.000 ~17.444 {fuse:48s}
summon minecraft:tnt ~-22.876 ~18.000 ~-4.733 {fuse:48s}
summon minecraft:tnt ~-7.339 ~18.000 ~-22.177 {fuse:48s}
