summon minecraft:tnt ~14.900 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~10.536 ~0.000 ~10.536 {fuse:0s}
summon minecraft:tnt ~0.000 ~0.000 ~14.900 {fuse:0s}
summon minecraft:tnt ~-10.536 ~0.000 ~10.536 {fuse:0s}
summon minecraft:tnt ~-14.900 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-10.536 ~0.000 ~-10.536 {fuse:0s}
summon minecraft:tnt ~-0.000 ~0.000 ~-14.900 {fuse:0s}
summon minecraft:tnt ~10.536 ~0.000 ~-10.536 {fuse:0s}
particle minecraft:flame ~5.426 ~0.000 ~-14.519 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~11.958 ~0.000 ~-9.861 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~15.287 ~0.000 ~-2.561 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~14.519 ~0.000 ~5.426 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~9.861 ~0.000 ~11.958 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~2.561 ~0.000 ~15.287 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-5.426 ~0.000 ~14.519 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-11.958 ~0.000 ~9.861 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-15.287 ~0.000 ~2.561 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-14.519 ~0.000 ~-5.426 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-9.861 ~0.000 ~-11.958 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-2.561 ~0.000 ~-15.287 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~4.708 ~7.702 ~-12.600 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~10.378 ~7.702 ~-8.558 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~13.266 ~7.702 ~-2.222 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~12.600 ~7.702 ~4.708 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~8.558 ~7.702 ~10.378 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~2.222 ~7.702 ~13.266 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-4.708 ~7.702 ~12.600 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-10.378 ~7.702 ~8.558 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-13.266 ~7.702 ~2.222 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-12.600 ~7.702 ~-4.708 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-8.558 ~7.702 ~-10.378 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-2.222 ~7.702 ~-13.266 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~2.747 ~13.367 ~-7.350 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~6.054 ~13.367 ~-4.992 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~7.739 ~13.367 ~-1.296 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~7.350 ~13.367 ~2.747 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~4.992 ~13.367 ~6.054 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~1.296 ~13.367 ~7.739 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-2.747 ~13.367 ~7.350 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-6.054 ~13.367 ~4.992 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-7.739 ~13.367 ~1.296 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-7.350 ~13.367 ~-2.747 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-4.992 ~13.367 ~-6.054 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-1.296 ~13.367 ~-7.739 0.15 0.15 0.15 0.03 2 force
