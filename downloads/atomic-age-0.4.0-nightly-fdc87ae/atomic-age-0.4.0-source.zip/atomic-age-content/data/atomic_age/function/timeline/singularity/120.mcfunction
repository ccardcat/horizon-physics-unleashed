summon minecraft:tnt ~7.000 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~3.500 ~0.000 ~6.062 {fuse:0s}
summon minecraft:tnt ~-3.500 ~0.000 ~6.062 {fuse:0s}
summon minecraft:tnt ~-7.000 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-3.500 ~0.000 ~-6.062 {fuse:0s}
summon minecraft:tnt ~3.500 ~0.000 ~-6.062 {fuse:0s}
particle minecraft:portal ~-9.942 ~2.000 ~-1.078 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-8.071 ~2.000 ~-5.904 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-4.038 ~2.000 ~-9.149 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~1.078 ~2.000 ~-9.942 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~5.904 ~2.000 ~-8.071 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~9.149 ~2.000 ~-4.038 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~9.942 ~2.000 ~1.078 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~8.071 ~2.000 ~5.904 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~4.038 ~2.000 ~9.149 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-1.078 ~2.000 ~9.942 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-5.904 ~2.000 ~8.071 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-9.149 ~2.000 ~4.038 0.15 0.15 0.15 0.03 2 force
particle minecraft:dragon_breath ~-3.977 ~7.647 ~0.431 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~-3.117 ~3.239 ~-2.507 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~-0.431 ~1.035 ~-3.977 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~2.507 ~2.325 ~-3.117 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~3.977 ~6.353 ~-0.431 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~3.117 ~10.761 ~2.507 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~0.431 ~12.965 ~3.977 0.25 0.25 0.25 0.03 4 force
particle minecraft:dragon_breath ~-2.507 ~11.675 ~3.117 0.25 0.25 0.25 0.03 4 force
