particle minecraft:flame ~3.748 ~0.300 ~-7.068 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~6.780 ~0.300 ~-4.247 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~7.995 ~0.300 ~-0.288 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~7.068 ~0.300 ~3.748 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~4.247 ~0.300 ~6.780 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.288 ~0.300 ~7.995 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-3.748 ~0.300 ~7.068 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-6.780 ~0.300 ~4.247 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-7.995 ~0.300 ~0.288 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-7.068 ~0.300 ~-3.748 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-4.247 ~0.300 ~-6.780 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.288 ~0.300 ~-7.995 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~2.249 ~3.000 ~4.241 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-0.173 ~3.000 ~4.797 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-2.548 ~3.000 ~4.068 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-4.241 ~3.000 ~2.249 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-4.797 ~3.000 ~-0.173 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-4.068 ~3.000 ~-2.548 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-2.249 ~3.000 ~-4.241 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~0.173 ~3.000 ~-4.797 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~2.548 ~3.000 ~-4.068 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~4.241 ~3.000 ~-2.249 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~4.797 ~3.000 ~0.173 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~4.068 ~3.000 ~2.548 0.15 0.15 0.15 0.03 2 force
playsound minecraft:block.note_block.pling master @a[distance=..128] ~0.000 ~0.000 ~0.000 3 1
title @a[distance=..96] actionbar {"translate":"atomic_age.countdown","with":[{"translate":"block.atomic_age.thermobaric_bomb"},"3"]}
