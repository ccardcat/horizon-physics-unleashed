summon minecraft:tnt ~2.000 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~1.414 ~0.000 ~1.414 {fuse:0s}
summon minecraft:tnt ~0.000 ~0.000 ~2.000 {fuse:0s}
summon minecraft:tnt ~-1.414 ~0.000 ~1.414 {fuse:0s}
summon minecraft:tnt ~-2.000 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-1.414 ~0.000 ~-1.414 {fuse:0s}
summon minecraft:tnt ~-0.000 ~0.000 ~-2.000 {fuse:0s}
summon minecraft:tnt ~1.414 ~0.000 ~-1.414 {fuse:0s}
particle minecraft:flash{color:[1.0,0.85,0.5]} ~0.000 ~0.000 ~0.000 0 0 0 0.03 1 force
particle minecraft:explosion_emitter ~0.000 ~0.000 ~0.000 2 2 2 0.03 3 force
playsound minecraft:entity.generic.explode master @a[distance=..128] ~0.000 ~0.000 ~0.000 3 0.5
particle minecraft:flame ~-1.452 ~0.000 ~-1.376 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.570 ~0.000 ~-1.917 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.465 ~0.000 ~-1.945 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~1.376 ~0.000 ~-1.452 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~1.917 ~0.000 ~-0.570 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~1.945 ~0.000 ~0.465 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~1.452 ~0.000 ~1.376 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.570 ~0.000 ~1.917 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.465 ~0.000 ~1.945 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-1.376 ~0.000 ~1.452 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-1.917 ~0.000 ~0.570 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-1.945 ~0.000 ~-0.465 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-1.260 ~0.994 ~-1.194 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.494 ~0.994 ~-1.664 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.404 ~0.994 ~-1.688 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~1.194 ~0.994 ~-1.260 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~1.664 ~0.994 ~-0.494 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~1.688 ~0.994 ~0.404 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~1.260 ~0.994 ~1.194 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.494 ~0.994 ~1.664 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.404 ~0.994 ~1.688 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-1.194 ~0.994 ~1.260 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-1.664 ~0.994 ~0.494 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-1.688 ~0.994 ~-0.404 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.735 ~1.725 ~-0.696 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.288 ~1.725 ~-0.971 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.236 ~1.725 ~-0.985 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.696 ~1.725 ~-0.735 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.971 ~1.725 ~-0.288 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.985 ~1.725 ~0.236 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.735 ~1.725 ~0.696 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.288 ~1.725 ~0.971 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.236 ~1.725 ~0.985 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.696 ~1.725 ~0.735 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.971 ~1.725 ~0.288 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.985 ~1.725 ~-0.236 0.15 0.15 0.15 0.03 2 force
title @a[distance=..96] actionbar {"translate":"atomic_age.detonation"}
