summon minecraft:tnt ~24.800 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~12.400 ~0.000 ~21.477 {fuse:0s}
summon minecraft:tnt ~-12.400 ~0.000 ~21.477 {fuse:0s}
summon minecraft:tnt ~-24.800 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-12.400 ~0.000 ~-21.477 {fuse:0s}
summon minecraft:tnt ~12.400 ~0.000 ~-21.477 {fuse:0s}
