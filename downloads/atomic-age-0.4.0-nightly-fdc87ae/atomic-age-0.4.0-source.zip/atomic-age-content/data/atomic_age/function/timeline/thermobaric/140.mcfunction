summon minecraft:tnt ~19.200 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~13.576 ~0.000 ~13.576 {fuse:0s}
summon minecraft:tnt ~0.000 ~0.000 ~19.200 {fuse:0s}
summon minecraft:tnt ~-13.576 ~0.000 ~13.576 {fuse:0s}
summon minecraft:tnt ~-19.200 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-13.576 ~0.000 ~-13.576 {fuse:0s}
summon minecraft:tnt ~-0.000 ~0.000 ~-19.200 {fuse:0s}
summon minecraft:tnt ~13.576 ~0.000 ~-13.576 {fuse:0s}
particle minecraft:flame ~13.598 ~0.000 ~-14.666 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~19.109 ~0.000 ~-5.903 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~19.500 ~0.000 ~4.443 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~14.666 ~0.000 ~13.598 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~5.903 ~0.000 ~19.109 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-4.443 ~0.000 ~19.500 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-13.598 ~0.000 ~14.666 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-19.109 ~0.000 ~5.903 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-19.500 ~0.000 ~-4.443 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-14.666 ~0.000 ~-13.598 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-5.903 ~0.000 ~-19.109 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~4.443 ~0.000 ~-19.500 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~11.800 ~9.938 ~-12.728 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~16.583 ~9.938 ~-5.122 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~16.923 ~9.938 ~3.856 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~12.728 ~9.938 ~11.800 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~5.122 ~9.938 ~16.583 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-3.856 ~9.938 ~16.923 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-11.800 ~9.938 ~12.728 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-16.583 ~9.938 ~5.122 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-16.923 ~9.938 ~-3.856 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-12.728 ~9.938 ~-11.800 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-5.122 ~9.938 ~-16.583 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~3.856 ~9.938 ~-16.923 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~6.883 ~17.248 ~-7.424 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~9.673 ~17.248 ~-2.988 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~9.871 ~17.248 ~2.249 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~7.424 ~17.248 ~6.883 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~2.988 ~17.248 ~9.673 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-2.249 ~17.248 ~9.871 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-6.883 ~17.248 ~7.424 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-9.673 ~17.248 ~2.988 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-9.871 ~17.248 ~-2.249 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-7.424 ~17.248 ~-6.883 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-2.988 ~17.248 ~-9.673 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~2.249 ~17.248 ~-9.871 0.15 0.15 0.15 0.03 2 force
