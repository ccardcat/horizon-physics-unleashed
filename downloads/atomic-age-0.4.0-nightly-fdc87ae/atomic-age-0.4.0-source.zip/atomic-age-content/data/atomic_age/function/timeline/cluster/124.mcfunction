summon minecraft:tnt ~-11.538 ~18.000 ~-15.745 {fuse:48s}
summon minecraft:tnt ~7.867 ~18.000 ~-17.865 {fuse:48s}
summon minecraft:tnt ~19.405 ~18.000 ~-2.119 {fuse:48s}
summon minecraft:tnt ~11.538 ~18.000 ~15.745 {fuse:48s}
summon minecraft:tnt ~-7.867 ~18.000 ~17.865 {fuse:48s}
summon minecraft:tnt ~-19.405 ~18.000 ~2.119 {fuse:48s}
