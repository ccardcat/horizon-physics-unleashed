particle minecraft:flame ~0.000 ~46.270 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~48.070 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~49.870 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~51.670 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~53.470 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~55.270 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~57.070 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~58.870 ~0.000 1 1 1 0.03 5 force
