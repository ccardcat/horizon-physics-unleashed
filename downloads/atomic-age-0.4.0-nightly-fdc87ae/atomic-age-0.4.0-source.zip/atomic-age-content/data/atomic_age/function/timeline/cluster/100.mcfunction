summon minecraft:tnt ~8.000 ~18.000 ~0.000 {fuse:48s}
summon minecraft:tnt ~4.000 ~18.000 ~6.928 {fuse:48s}
summon minecraft:tnt ~-4.000 ~18.000 ~6.928 {fuse:48s}
summon minecraft:tnt ~-8.000 ~18.000 ~0.000 {fuse:48s}
summon minecraft:tnt ~-4.000 ~18.000 ~-6.928 {fuse:48s}
summon minecraft:tnt ~4.000 ~18.000 ~-6.928 {fuse:48s}
particle minecraft:flash{color:[1.0,0.85,0.5]} ~0.000 ~0.000 ~0.000 0 0 0 0.03 1 force
particle minecraft:explosion_emitter ~0.000 ~0.000 ~0.000 2 2 2 0.03 3 force
playsound minecraft:entity.generic.explode master @a[distance=..128] ~0.000 ~0.000 ~0.000 3 0.5
particle minecraft:flame ~9.074 ~18.000 ~4.202 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~5.758 ~18.000 ~8.176 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.898 ~18.000 ~9.960 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-4.202 ~18.000 ~9.074 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-8.176 ~18.000 ~5.758 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-9.960 ~18.000 ~0.898 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-9.074 ~18.000 ~-4.202 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-5.758 ~18.000 ~-8.176 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.898 ~18.000 ~-9.960 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~4.202 ~18.000 ~-9.074 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~8.176 ~18.000 ~-5.758 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~9.960 ~18.000 ~-0.898 0.15 0.15 0.15 0.03 2 force
particle minecraft:large_smoke ~0.000 ~0.000 ~0.000 8 8 8 0.03 12 force
title @a[distance=..96] actionbar {"translate":"atomic_age.detonation"}
