particle minecraft:flame ~0.000 ~33.053 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~34.853 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~36.653 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~38.453 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~40.253 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~42.053 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~43.853 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~45.653 ~0.000 1 1 1 0.03 5 force
