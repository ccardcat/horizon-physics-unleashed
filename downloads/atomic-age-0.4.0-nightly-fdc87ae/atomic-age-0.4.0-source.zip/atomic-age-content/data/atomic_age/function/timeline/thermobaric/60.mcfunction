particle minecraft:flame ~0.324 ~0.300 ~5.991 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-2.715 ~0.300 ~5.350 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-5.027 ~0.300 ~3.276 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-5.991 ~0.300 ~0.324 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-5.350 ~0.300 ~-2.715 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-3.276 ~0.300 ~-5.027 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.324 ~0.300 ~-5.991 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~2.715 ~0.300 ~-5.350 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~5.027 ~0.300 ~-3.276 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~5.991 ~0.300 ~-0.324 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~5.350 ~0.300 ~2.715 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~3.276 ~0.300 ~5.027 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~0.194 ~3.000 ~-3.595 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~1.966 ~3.000 ~-3.016 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~3.210 ~3.000 ~-1.629 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~3.595 ~3.000 ~0.194 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~3.016 ~3.000 ~1.966 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~1.629 ~3.000 ~3.210 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-0.194 ~3.000 ~3.595 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-1.966 ~3.000 ~3.016 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-3.210 ~3.000 ~1.629 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-3.595 ~3.000 ~-0.194 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-3.016 ~3.000 ~-1.966 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-1.629 ~3.000 ~-3.210 0.15 0.15 0.15 0.03 2 force
playsound minecraft:block.note_block.pling master @a[distance=..128] ~0.000 ~0.000 ~0.000 3 1.2
title @a[distance=..96] actionbar {"translate":"atomic_age.countdown","with":[{"translate":"block.atomic_age.thermobaric_bomb"},"2"]}
