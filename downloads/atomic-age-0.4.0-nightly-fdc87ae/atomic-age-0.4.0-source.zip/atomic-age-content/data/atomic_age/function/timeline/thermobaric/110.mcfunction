summon minecraft:tnt ~6.300 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~4.455 ~0.000 ~4.455 {fuse:0s}
summon minecraft:tnt ~0.000 ~0.000 ~6.300 {fuse:0s}
summon minecraft:tnt ~-4.455 ~0.000 ~4.455 {fuse:0s}
summon minecraft:tnt ~-6.300 ~0.000 ~0.000 {fuse:0s}
summon minecraft:tnt ~-4.455 ~0.000 ~-4.455 {fuse:0s}
summon minecraft:tnt ~-0.000 ~0.000 ~-6.300 {fuse:0s}
summon minecraft:tnt ~4.455 ~0.000 ~-4.455 {fuse:0s}
particle minecraft:flame ~-2.665 ~0.000 ~-5.929 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.657 ~0.000 ~-6.467 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~3.802 ~0.000 ~-5.272 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~5.929 ~0.000 ~-2.665 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~6.467 ~0.000 ~0.657 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~5.272 ~0.000 ~3.802 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~2.665 ~0.000 ~5.929 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.657 ~0.000 ~6.467 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-3.802 ~0.000 ~5.272 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-5.929 ~0.000 ~2.665 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-6.467 ~0.000 ~-0.657 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-5.272 ~0.000 ~-3.802 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-2.312 ~3.230 ~-5.145 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.570 ~3.230 ~-5.612 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~3.300 ~3.230 ~-4.575 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~5.145 ~3.230 ~-2.312 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~5.612 ~3.230 ~0.570 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~4.575 ~3.230 ~3.300 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~2.312 ~3.230 ~5.145 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.570 ~3.230 ~5.612 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-3.300 ~3.230 ~4.575 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-5.145 ~3.230 ~2.312 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-5.612 ~3.230 ~-0.570 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-4.575 ~3.230 ~-3.300 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-1.349 ~5.606 ~-3.001 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.332 ~5.606 ~-3.274 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~1.925 ~5.606 ~-2.669 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~3.001 ~5.606 ~-1.349 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~3.274 ~5.606 ~0.332 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~2.669 ~5.606 ~1.925 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~1.349 ~5.606 ~3.001 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.332 ~5.606 ~3.274 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-1.925 ~5.606 ~2.669 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-3.001 ~5.606 ~1.349 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-3.274 ~5.606 ~-0.332 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-2.669 ~5.606 ~-1.925 0.15 0.15 0.15 0.03 2 force
