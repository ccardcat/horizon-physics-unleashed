particle minecraft:flame ~-8.569 ~0.300 ~5.155 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-9.998 ~0.300 ~0.180 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-8.749 ~0.300 ~-4.843 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-5.155 ~0.300 ~-8.569 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-0.180 ~0.300 ~-9.998 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~4.843 ~0.300 ~-8.749 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~8.569 ~0.300 ~-5.155 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~9.998 ~0.300 ~-0.180 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~8.749 ~0.300 ~4.843 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~5.155 ~0.300 ~8.569 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~0.180 ~0.300 ~9.998 0.15 0.15 0.15 0.03 2 force
particle minecraft:flame ~-4.843 ~0.300 ~8.749 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-5.141 ~3.000 ~-3.093 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-2.906 ~3.000 ~-5.249 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~0.108 ~3.000 ~-5.999 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~3.093 ~3.000 ~-5.141 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~5.249 ~3.000 ~-2.906 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~5.999 ~3.000 ~0.108 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~5.141 ~3.000 ~3.093 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~2.906 ~3.000 ~5.249 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-0.108 ~3.000 ~5.999 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-3.093 ~3.000 ~5.141 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-5.249 ~3.000 ~2.906 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-5.999 ~3.000 ~-0.108 0.15 0.15 0.15 0.03 2 force
playsound minecraft:block.note_block.pling master @a[distance=..128] ~0.000 ~0.000 ~0.000 3 0.8
title @a[distance=..96] actionbar {"translate":"atomic_age.countdown","with":[{"translate":"block.atomic_age.thermobaric_bomb"},"4"]}
