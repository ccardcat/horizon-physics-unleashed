particle minecraft:portal ~3.748 ~0.300 ~-7.068 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~6.780 ~0.300 ~-4.247 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~7.995 ~0.300 ~-0.288 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~7.068 ~0.300 ~3.748 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~4.247 ~0.300 ~6.780 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~0.288 ~0.300 ~7.995 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-3.748 ~0.300 ~7.068 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-6.780 ~0.300 ~4.247 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-7.995 ~0.300 ~0.288 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-7.068 ~0.300 ~-3.748 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-4.247 ~0.300 ~-6.780 0.15 0.15 0.15 0.03 2 force
particle minecraft:portal ~-0.288 ~0.300 ~-7.995 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~2.249 ~3.000 ~4.241 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-0.173 ~3.000 ~4.797 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-2.548 ~3.000 ~4.068 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-4.241 ~3.000 ~2.249 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-4.797 ~3.000 ~-0.173 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-4.068 ~3.000 ~-2.548 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~-2.249 ~3.000 ~-4.241 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~0.173 ~3.000 ~-4.797 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~2.548 ~3.000 ~-4.068 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~4.241 ~3.000 ~-2.249 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~4.797 ~3.000 ~0.173 0.15 0.15 0.15 0.03 2 force
particle minecraft:end_rod ~4.068 ~3.000 ~2.548 0.15 0.15 0.15 0.03 2 force
playsound minecraft:block.note_block.pling master @a[distance=..128] ~0.000 ~0.000 ~0.000 3 1
execute as @e[type=!player,type=!item,type=!tnt,type=!marker,tag=!atomic.blast,distance=2..18] at @s facing entity @e[type=marker,tag=atomic.blast,sort=nearest,limit=1] feet run tp @s ^ ^ ^0.65
title @a[distance=..96] actionbar {"translate":"atomic_age.countdown","with":[{"translate":"block.atomic_age.singularity_bomb"},"3"]}
