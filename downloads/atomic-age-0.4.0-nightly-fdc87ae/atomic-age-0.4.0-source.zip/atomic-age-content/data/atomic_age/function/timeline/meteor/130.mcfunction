particle minecraft:flame ~0.000 ~37.306 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~39.106 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~40.906 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~42.706 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~44.506 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~46.306 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~48.106 ~0.000 1 1 1 0.03 5 force
particle minecraft:flame ~0.000 ~49.906 ~0.000 1 1 1 0.03 5 force
