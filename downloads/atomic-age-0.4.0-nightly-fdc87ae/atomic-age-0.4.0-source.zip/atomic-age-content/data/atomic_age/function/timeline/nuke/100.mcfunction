summon minecraft:tnt ~0.000 ~0.000 ~0.000 {fuse:0s}
particle minecraft:flash{color:[1.0,0.85,0.5]} ~0.000 ~0.000 ~0.000 0 0 0 0.03 1 force
particle minecraft:explosion_emitter ~0.000 ~0.000 ~0.000 2 2 2 0.03 3 force
playsound minecraft:entity.generic.explode master @a[distance=..128] ~0.000 ~0.000 ~0.000 3 0.5
particle minecraft:large_smoke ~0.000 ~0.000 ~0.000 2 2 2 0.03 20 force
particle minecraft:campfire_cosy_smoke ~-3.428 ~0.000 ~2.062 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-3.999 ~0.000 ~0.072 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-3.500 ~0.000 ~-1.937 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-2.062 ~0.000 ~-3.428 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-0.072 ~0.000 ~-3.999 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~1.937 ~0.000 ~-3.500 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~3.428 ~0.000 ~-2.062 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~3.999 ~0.000 ~-0.072 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~3.500 ~0.000 ~1.937 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~2.062 ~0.000 ~3.428 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~0.072 ~0.000 ~3.999 0.15 0.15 0.15 0.03 2 force
particle minecraft:campfire_cosy_smoke ~-1.937 ~0.000 ~3.500 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~0.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~0.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~0.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~0.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~0.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~0.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~0.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~0.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~0.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~0.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~0.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
particle minecraft:cloud ~0.000 ~1.000 ~0.000 0.15 0.15 0.15 0.03 2 force
title @a[distance=..96] actionbar {"translate":"atomic_age.detonation"}
